﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciciosL
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exercicio1 ex1 = new Exercicio1();
            //Exercicio2 ex2 = new Exercicio2();
            Exercicio3 ex3 = new Exercicio3();

            Console.ReadKey();
        }
    }
}
