﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriz
{
    class Matriz1
    {
        public Matriz1()
        {
            int[,] m = new int[5, 5];
            int lin, col;

            for (lin = 0; lin < 5; lin++)
            {
                for (col = 0; col < 5; col++)
                {
                    Console.WriteLine("Digite um número");
                    m[lin, col] = int.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine("\nElementos da matriz");
            for (lin = 0; lin < 5; lin++)
            {
                for (col = 0; col < 5; col++)
                {
                    Console.Write(m[lin, col] + "\t");
                }
                Console.WriteLine();
            }

            Console.WriteLine("\nElementos da matriz metade");
            for (lin = 0; lin < 5; lin++)
            {
                for (col = 0; col < 5; col++)
                {
                    m[lin, col] = m[lin, col] / 2;
                    Console.Write(m[lin, col] + "\t");
                }
                Console.WriteLine();
            }
        }
    }
}

