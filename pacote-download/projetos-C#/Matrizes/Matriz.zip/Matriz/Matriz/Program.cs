﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriz
{
    class Program
    {
        static void Main(string[] args)
        {
            Matriz1 m1 = new Matriz1();

            Console.ReadKey();
        }
    }
}
