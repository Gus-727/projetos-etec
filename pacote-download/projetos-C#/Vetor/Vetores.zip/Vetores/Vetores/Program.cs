﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vetores
{
    class Program
    {
        static void Main(string[] args)
        {
            //Vetor1 v1 = new Vetor1();
            Vetor3 v3 = new Vetor3();

            Console.ReadKey();
        }
    }
}
